package com.tts.usersapi;

public enum Status {

    IN_PROGRESS, //
    COMPLETED, //
    CANCELLED
}